'use client';
import React from 'react';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';
import { persistor, store } from './store';

export default function StoreProvider({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <Provider store={store}>
      <PersistGate persistor={persistor} loading={null}>
        {() => <>{children}</>}
      </PersistGate>
    </Provider>
  );
}

